package com.onlinestore.servlets;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.onlinestore.db.OnlineStoreDBConnection;

/**
 * Servlet implementation class RetrieveByNameServlet
 */
@WebServlet(name = "RetrieveImage", urlPatterns = { "/displayphoto" })
public class RetrieveImage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con = null;
	PreparedStatement pst = null;
	ResultSet rs1 = null;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		int id = Integer.parseInt(request.getParameter("id"));

		try {

			con = OnlineStoreDBConnection.getDbConnection();
			pst = con.prepareStatement("select img from products_tbl where p_id=?");
			pst.setInt(1, id);
			rs1 = pst.executeQuery();
			if (rs1 != null) {
				rs1.next();
				Blob b = rs1.getBlob("img");
				response.setContentType("image/jpeg");
				response.setContentLength((int) b.length());
				InputStream is = b.getBinaryStream();
				OutputStream os = response.getOutputStream();
				byte buf[] = new byte[(int) b.length()];
				is.read(buf);
				os.write(buf);
				os.close();
			}
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void destroy() {
		super.destroy();
		try {
			rs1.close();
			pst.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
}
