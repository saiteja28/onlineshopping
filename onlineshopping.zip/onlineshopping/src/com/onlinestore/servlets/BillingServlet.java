package com.onlinestore.servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.onlinestore.db.OnlineStoreDBConnection;

/**
 * Servlet implementation class BillingServlet
 */
@WebServlet("/BillingServlet")
public class BillingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con = null;
	PreparedStatement pst = null;
	ResultSet rs = null;
	int i = 0;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		try {
			response.setContentType("text/html;charset=UTF-8");
			con = OnlineStoreDBConnection.getDbConnection();
			Enumeration<String> names = session.getAttributeNames();
			int temp = 0;
			String[] prods = new String[100];
			while (names.hasMoreElements()) {
				String string = names.nextElement();
				prods[temp] = (String) session.getAttribute(string);
				temp++;

			}
			for (i = 0; i < temp; i++) {
				String sql = "select * from products_tbl where P_NAME=?";
				pst = con.prepareStatement(sql);
				pst.setString(1, prods[i]);
				rs = pst.executeQuery();
				if (rs.next()) {
					request.setAttribute("rs" + i, rs);

				}
			}

			request.getRequestDispatcher("displayProducts.jsp?i=" + i).forward(request, response);

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void destroy() {
		super.destroy();
		try {
			rs.close();
			pst.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
