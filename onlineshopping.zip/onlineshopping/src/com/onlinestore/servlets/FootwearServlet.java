package com.onlinestore.servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class RetrieveByNameServlet
 */
@WebServlet("/FootwearServlet")
public class FootwearServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con = null;
	PreparedStatement pst = null;
	ResultSet rs = null;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String[] footwear = request.getParameterValues("footwear");

		HttpSession session = request.getSession();

		int k = 0;
		for (String string : footwear) {
			session.setAttribute("footwear" + k, string);
			k++;
		}
		response.sendRedirect("home.jsp");
	}

	@Override
	public void destroy() {
		super.destroy();
		try {
			rs.close();
			pst.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
}
