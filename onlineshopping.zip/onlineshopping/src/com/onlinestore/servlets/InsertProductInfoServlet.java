package com.onlinestore.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.onlinestore.db.OnlineStoreDBConnection;

/**
 * Servlet implementation class CricketServlet
 */
@WebServlet("/insertServlet")
@MultipartConfig
public class InsertProductInfoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static Connection con = null;
	static PreparedStatement pst = null;
	static Scanner scanner = null;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter writer = response.getWriter();
		int id = Integer.parseInt(request.getParameter("id"));
		String pname = request.getParameter("pname");
		String ptype = request.getParameter("ptype");
		int price = Integer.parseInt(request.getParameter("price"));

		Part photo = request.getPart("pic");

		try {
			con = OnlineStoreDBConnection.getDbConnection();
			String sql = "insert into products_tbl values(?,?,?,?,?)";
			pst = con.prepareStatement(sql);
			pst.setInt(1, id);
			pst.setString(2, pname);
			pst.setString(3, ptype);
			pst.setInt(4, price);
			pst.setBinaryStream(5, photo.getInputStream(), (int) photo.getSize());
			int insertion = pst.executeUpdate();
			if (insertion > 0) {
				writer.println("inserted");
			} else {
				writer.println("not inserted");
			}
			con.commit();
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	@Override
	public void destroy() {
		super.destroy();
		try {
			pst.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
