package com.onlinestore.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class OnlineStoreDBConnection {

	public static Connection getDbConnection() throws SQLException, ClassNotFoundException {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@192.168.1.27:1521:orcl", "DB336",
				"pass123");
		return connection;
	}
}
