package com.onlinestore.users;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.onlinestore.db.OnlineStoreDBConnection;

/**
 * Servlet implementation class UserSignUpServlet
 */
@WebServlet("/UserSignUpServlet")
public class UserSignUpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UserSignUpServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	Connection con = null;
	PreparedStatement pst = null;
	ResultSet rs = null;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String email_id = request.getParameter("email1");
		String usr = request.getParameter("uname1");
		String pwd = request.getParameter("pwd1");
		int mobile = Integer.parseInt(request.getParameter("mobile"));
		String address = request.getParameter("address");
		try {
			con = OnlineStoreDBConnection.getDbConnection();
			pst = con.prepareStatement("select * from user_tbl where email_id=?");
			pst.setString(1, email_id);
			rs = pst.executeQuery();
			if (rs.next()) {
				if (rs.getString("email_id").equals(email_id)) {
					response.sendRedirect("signup.html");
				} else {
					response.sendRedirect("signup.html");
				}
			} else {
				pst = con.prepareStatement("insert into user_tbl values(?,?,?,?,?)");
				pst.setString(1, usr);
				pst.setString(2, pwd);
				pst.setInt(4, mobile);
				pst.setString(3, email_id);
				pst.setString(5, address);
				int i = pst.executeUpdate();
				System.out.println("row inserted" + i);
				response.sendRedirect("signin.html");
			}
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void destroy() {
		try {
			rs.close();
			pst.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
